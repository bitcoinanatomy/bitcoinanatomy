# OpenSeadragon Flat Toolbar Icons
Simple, flat design toolbar icons for OpenSeadragon
[https://github.com/openseadragon/openseadragon](https://github.com/openseadragon/openseadragon)

Demo:
[http://droneservices.getyournet.ch/beispiele-luftaufnahmen-mit-drohne](http://droneservices.getyournet.ch/beispiele-luftaufnahmen-mit-drohne)

![alt tag](https://cloud.githubusercontent.com/assets/5383762/9150698/70f23bfe-3de8-11e5-961e-5239fa67e94e.png)

