# OpenSeadragon SVG Icons

Vector icon set for use with [OpenSeadragon](https://github.com/openseadragon/openseadragon), based on the [Feather](https://github.com/feathericons/feather) icon set.
